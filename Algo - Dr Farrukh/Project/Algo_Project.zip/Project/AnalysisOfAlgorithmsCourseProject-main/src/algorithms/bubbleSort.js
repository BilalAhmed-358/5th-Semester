const swap = (arr, i, j) => {
    const temp = arr[i]
    arr[i] = arr[j]
    arr[j] = temp
}

const bubbleSort = (blocks) => {
    var startDate = new Date();
    const duplicateArray = blocks.slice() // copying blocks array
    const orderOfTraversal = []

    let i, j

    for (i = 0; i < duplicateArray.length; i++) {
        for (j = 0; j < duplicateArray.length - i - 1; j++) {

            orderOfTraversal.push([j, j + 1, null, null])                  // Compare
            if (duplicateArray[j] > duplicateArray[j + 1]) {
                swap(duplicateArray, j, j + 1)
                orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
            }
        }
        orderOfTraversal.push([null, null, null, j]) // j-th element is in correct position ( Sorted )
    }
    var endDate = new Date();
    let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
    alert(str)
    return orderOfTraversal
}

let orderOfTraversal = []
let duplicateArray;
const fromBook_7_4_5 = (blocks) => {

    var startDate = new Date();
    duplicateArray = blocks.slice() // Copying blocks array
    hybrid_quick_sort(duplicateArray, 0, duplicateArray.length - 1)
    for (let i = 0; i < duplicateArray.length; i++) {
        orderOfTraversal.push([null, null, null, i])
    }
    var endDate = new Date();
    let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
    alert(str)
    return orderOfTraversal
}



const partition = (duplicateArray, l, r) => {
    const pivot = l
    let j = l

    for (let i = l + 1; i <= r; i++) {
        orderOfTraversal.push([i, pivot, null, null])
        if (duplicateArray[i] < duplicateArray[pivot]) {
            j += 1
            orderOfTraversal.push([i, j, duplicateArray.slice(), null])
            swap(duplicateArray, i, j)
            orderOfTraversal.push([i, j, duplicateArray.slice(), null])
        }
    }
    orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
    swap(duplicateArray, pivot, j)
    orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
    orderOfTraversal.push([null, null, null, j])
    return j
}



const hybrid_quick_sort = (duplicateArray, l, r) => {
    console.log("In hybrid quick sort value of l and r is " + l + " " + r)
    while (l < r) {
        if (r - l + 1 < 10) {
            insertionSort_(duplicateArray, l, r);
            break
        }
        else {
            let m = partition(duplicateArray, l, r)
            if (m - l < r - m) {
                hybrid_quick_sort(duplicateArray, l, m - 1)
                l = m + 1
            }
            else {
                hybrid_quick_sort(duplicateArray, m + 1, r)
                r = m - 1
            }
        }

    }
    return
}

const insertionSort_ = (blocks_, l, r) => {
    console.log("In insertion sort value of l and r is " + l + " " + r)
    let i, j

    for (i = l + 1; i < r + 1; i++) {
        j = i - 1
        while (j >= 0 && duplicateArray[j] > duplicateArray[j + 1]) {
            swap(duplicateArray, j, j + 1)
            orderOfTraversal.push([j, j + 1, null, null])              // Compare
            orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
            j -= 1

        }
    }
    for (i = l; i < r + 1; i++) {
        orderOfTraversal.push([null, null, null, i])
    }
}
const fromBook_8_2_4 = (blocks) => {
    var startDate = new Date();
    let duplicateArray = blocks.slice() // copying blocks array
    let min = Math.min(...duplicateArray)
    let max = Math.max(...duplicateArray)

    let i = min,
        j = 0,
        len = duplicateArray.length,
        count = [];
    for (i; i <= max; i++) {
        count[i] = 0;
    }
    for (i = 0; i < len; i++) {
        count[duplicateArray[i]] += 1;
    }
    console.log(min)
    for (i = min; i <= max; i++) {
        while (count[i] > 0) {
            duplicateArray[j] = i;
            orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
            console.log(duplicateArray[i])
            count[i]--;
            orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
            j++;
        }
    }
    console.log(duplicateArray)
    let a = prompt("Enter 'a' i.e. the lower limit of the range")
    let b = prompt("Enter 'b' i.e. the upper limit of the range")
    let rangeCount = 0
    for (let i = 0; i < duplicateArray.length; i++) {
        if (duplicateArray[i] >= a && duplicateArray[i] <= b)
            rangeCount++
    }
    alert("There are " + rangeCount + " number that lie within the range of " + a + " and " + b)
    var endDate = new Date();
    let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
    alert(str)
    return orderOfTraversal;
}

function getDigit(num, place) {
    return Math.floor(Math.abs(num) / Math.pow(10, place)) % 10
}

function digitCount(num) {
    if (num === 0) return 1
    return Math.floor(Math.log10(Math.abs(num))) + 1
}

function mostDigits(nums) {
    let maxDigits = 0
    for (let i = 0; i < nums.length; i++) {
        maxDigits = Math.max(maxDigits, digitCount(nums[i]))
    }
    return maxDigits
}

const radixSort = (blocks) => {
    var startDate = new Date();
    let duplicateArray = blocks.slice()
    let holder = []
    let maxDigitCount = mostDigits(duplicateArray)
    for (let k = 0; k < maxDigitCount; k++) {
        holder = []

        let digitBuckets = Array.from({ length: 10 }, () => []) // [[], [], [],...]
        for (let i = 0; i < duplicateArray.length; i++) {
            let digit = getDigit(duplicateArray[i], k)
            digitBuckets[digit].push(duplicateArray[i])
        }
        for (let i = 0; i < digitBuckets.length; i++) {
            for (let j = 0; j < digitBuckets[i].length; j++) {
                if (digitBuckets[i][j] != []) {
                    holder.push(digitBuckets[i][j])
                }

            }

        }
        console.log(holder)
        orderOfTraversal.push([null, null, holder.slice(), null]) // Swap
        console.log(duplicateArray)
        // New orderOfTraversal after each loop
        duplicateArray = [].concat(...digitBuckets)
    }
    for (let i = 0; i < holder.length; i++) {
        orderOfTraversal.push([null, null, null, i]) // j-th element is in correct position ( Sorted )
    }
    var endDate = new Date();
    let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
    alert(str)
    // return duplicateArray
    return orderOfTraversal
}

const countSort = (blocks) => {
    var startDate = new Date();
    let duplicateArray = blocks.slice() // copying blocks array
    let min = Math.min(...duplicateArray)
    let max = Math.max(...duplicateArray)

    let i = min,
        j = 0,
        len = duplicateArray.length,
        count = [];
    for (i; i <= max; i++) {
        count[i] = 0;
    }
    for (i = 0; i < len; i++) {
        count[duplicateArray[i]] += 1;
    }
    console.log(min)
    for (i = min; i <= max; i++) {
        while (count[i] > 0) {
            duplicateArray[j] = i;
            orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
            console.log(duplicateArray[i])
            count[i]--;
            orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
            j++;
        }
    }
    var endDate = new Date();
    let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
    alert(str)
    return orderOfTraversal;
};


export default bubbleSort

