import React, { useState, useEffect } from 'react'
import './App.css'

import Navbar from './components/Navbar/Navbar'
import ListBlocks from './components/ListBlocks/ListBlocks'
import Legends from './components/Legends/Legends'

// Algorithms
import bubbleSort from './algorithms/bubbleSort'
import insertionSort from './algorithms/insertionSort'
import selectionSort from './algorithms/selectionSort'
import mergeSort from './algorithms/mergeSort'
import quickSort from './algorithms/quickSort'
import heapSort from './algorithms/heapSort'
import countSort from './algorithms/countSort'
import radixSort from './algorithms/radixSort'
import fromBook_7_4_5 from './algorithms/fromBook_7_4_5'
import fromBook_8_2_4 from './algorithms/fromBook_8_2_4'


function App() {
	// Generating shuffled array of 1 to len
	const generateRandomArray = (len) => {
		setCompleted(false)
		setSorting(false)
		setSortedIndex([])

		const randomArray = Array.from(Array(len + 1).keys()).slice(1);
		for (let i = randomArray.length - 1; i > 0; i--) {
			const randomIndex = Math.floor(Math.random() * (i - 1))
			const temp = randomArray[i]
			randomArray[i] = randomArray[randomIndex]
			randomArray[randomIndex] = temp
		}

		setBlocks(randomArray)
	}

	// States
	const [algo, setAlgo] = useState('bubbleSort')
	const [len, setLength] = useState(30)
	const [blocks, setBlocks] = useState([])
	const [sorting, setSorting] = useState(false)
	const [completed, setCompleted] = useState(true)
	const [speed, setSpeed] = useState(250)
	const [compare, setCompare] = useState([])
	const [swap, setSwap] = useState([])
	const [sortedIndex, setSortedIndex] = useState([])
	// Generating random array every time the length is changed by th user
	useEffect(() => {
		generateRandomArray(len)
	}, [len, algo])

	// setting the selected algorithm
	const handleAlgo = (event) => {
		setAlgo(event.target.value)
	}

	// handling the length of the array
	const handleLength = (event) => {
		setLength(Number(event.target.value))
	}

	// handling the speed of sorting
	const handleSpeed = (event) => {
		setSpeed(Math.ceil(1200 / Number(event.target.value)))
	}

	// Sorting according to the algorithm
	const handleSort = () => {

		const sortAccOrder = (order) => {
			(function loop(i) {
				setTimeout(function () {
					const [j, k, arr, index] = order[i]
					setCompare([j, k])
					setSwap([])

					if (index !== null) {
						setSortedIndex((prevState) => (
							[...prevState, index]
						))
					}

					if (arr) {

						setBlocks(arr)
						if (j !== null || k != null)
							setSwap([j, k])

					}

					if (++i < order.length) {
						loop(i)
					} else {
						setSorting(false)
						setCompleted(true)
					}
				}, speed)
			})(0)

		}

		setSorting(true)


		const swap_ = (arr, i, j) => {
			const temp = arr[i]
			arr[i] = arr[j]
			arr[j] = temp
		}

		const bubbleSort_ = (blocks) => {
			var startDate = new Date();
			const duplicateArray = blocks.slice() // copying blocks array
			const orderOfTraversal = []

			let i, j

			for (i = 0; i < duplicateArray.length; i++) {
				for (j = 0; j < duplicateArray.length - i - 1; j++) {

					orderOfTraversal.push([j, j + 1, null, null])                  // Compare
					if (duplicateArray[j] > duplicateArray[j + 1]) {
						swap(duplicateArray, j, j + 1)
						orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
					}
				}
				orderOfTraversal.push([null, null, null, j]) // j-th element is in correct position ( Sorted )
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal
		}

		let orderOfTraversal_ = []
		let duplicateArray_;
		const fromBook_7_4_5_ = (blocks) => {

			var startDate = new Date();
			duplicateArray = blocks.slice() // Copying blocks array
			hybrid_quick_sort(duplicateArray, 0, duplicateArray.length - 1)
			for (let i = 0; i < duplicateArray.length; i++) {
				orderOfTraversal.push([null, null, null, i])
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal
		}



		const partition_ = (duplicateArray, l, r) => {
			const pivot = l
			let j = l

			for (let i = l + 1; i <= r; i++) {
				orderOfTraversal.push([i, pivot, null, null])
				if (duplicateArray[i] < duplicateArray[pivot]) {
					j += 1
					orderOfTraversal.push([i, j, duplicateArray.slice(), null])
					swap(duplicateArray, i, j)
					orderOfTraversal.push([i, j, duplicateArray.slice(), null])
				}
			}
			orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
			swap(duplicateArray, pivot, j)
			orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
			orderOfTraversal.push([null, null, null, j])
			return j
		}



		const hybrid_quick_sort_ = (duplicateArray, l, r) => {
			console.log("In hybrid quick sort value of l and r is " + l + " " + r)
			while (l < r) {
				if (r - l + 1 < 10) {
					insertionSort_(duplicateArray, l, r);
					break
				}
				else {
					let m = partition(duplicateArray, l, r)
					if (m - l < r - m) {
						hybrid_quick_sort(duplicateArray, l, m - 1)
						l = m + 1
					}
					else {
						hybrid_quick_sort(duplicateArray, m + 1, r)
						r = m - 1
					}
				}

			}
			return
		}

		const insertionSort__ = (blocks_, l, r) => {
			console.log("In insertion sort value of l and r is " + l + " " + r)
			let i, j

			for (i = l + 1; i < r + 1; i++) {
				j = i - 1
				while (j >= 0 && duplicateArray[j] > duplicateArray[j + 1]) {
					swap(duplicateArray, j, j + 1)
					orderOfTraversal.push([j, j + 1, null, null])              // Compare
					orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
					j -= 1

				}
			}
			for (i = l; i < r + 1; i++) {
				orderOfTraversal.push([null, null, null, i])
			}
		}
		const fromBook_8_2_4_ = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice() // copying blocks array
			let min = Math.min(...duplicateArray)
			let max = Math.max(...duplicateArray)

			let i = min,
				j = 0,
				len = duplicateArray.length,
				count = [];
			for (i; i <= max; i++) {
				count[i] = 0;
			}
			for (i = 0; i < len; i++) {
				count[duplicateArray[i]] += 1;
			}
			console.log(min)
			for (i = min; i <= max; i++) {
				while (count[i] > 0) {
					duplicateArray[j] = i;
					orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
					console.log(duplicateArray[i])
					count[i]--;
					orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
					j++;
				}
			}
			console.log(duplicateArray)
			let a = prompt("Enter 'a' i.e. the lower limit of the range")
			let b = prompt("Enter 'b' i.e. the upper limit of the range")
			let rangeCount = 0
			for (let i = 0; i < duplicateArray.length; i++) {
				if (duplicateArray[i] >= a && duplicateArray[i] <= b)
					rangeCount++
			}
			alert("There are " + rangeCount + " number that lie within the range of " + a + " and " + b)
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal;
		}

		function getDigit(num, place) {
			return Math.floor(Math.abs(num) / Math.pow(10, place)) % 10
		}

		function digitCount(num) {
			if (num === 0) return 1
			return Math.floor(Math.log10(Math.abs(num))) + 1
		}

		function mostDigits(nums) {
			let maxDigits = 0
			for (let i = 0; i < nums.length; i++) {
				maxDigits = Math.max(maxDigits, digitCount(nums[i]))
			}
			return maxDigits
		}

		const radixSort_ = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice()
			let holder = []
			let maxDigitCount = mostDigits(duplicateArray)
			for (let k = 0; k < maxDigitCount; k++) {
				holder = []

				let digitBuckets = Array.from({ length: 10 }, () => []) // [[], [], [],...]
				for (let i = 0; i < duplicateArray.length; i++) {
					let digit = getDigit(duplicateArray[i], k)
					digitBuckets[digit].push(duplicateArray[i])
				}
				for (let i = 0; i < digitBuckets.length; i++) {
					for (let j = 0; j < digitBuckets[i].length; j++) {
						if (digitBuckets[i][j] != []) {
							holder.push(digitBuckets[i][j])
						}

					}

				}
				console.log(holder)
				orderOfTraversal.push([null, null, holder.slice(), null]) // Swap
				console.log(duplicateArray)
				// New orderOfTraversal after each loop
				duplicateArray = [].concat(...digitBuckets)
			}
			for (let i = 0; i < holder.length; i++) {
				orderOfTraversal.push([null, null, null, i]) // j-th element is in correct position ( Sorted )
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			// return duplicateArray
			return orderOfTraversal
		}

		const countSort_ = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice() // copying blocks array
			let min = Math.min(...duplicateArray)
			let max = Math.max(...duplicateArray)

			let i = min,
				j = 0,
				len = duplicateArray.length,
				count = [];
			for (i; i <= max; i++) {
				count[i] = 0;
			}
			for (i = 0; i < len; i++) {
				count[duplicateArray[i]] += 1;
			}
			console.log(min)
			for (i = min; i <= max; i++) {
				while (count[i] > 0) {
					duplicateArray[j] = i;
					orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
					console.log(duplicateArray[i])
					count[i]--;
					orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
					j++;
				}
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal;
		};
		const swap = (arr, i, j) => {
			const temp = arr[i]
			arr[i] = arr[j]
			arr[j] = temp
		}

		const bubbleSort = (blocks) => {
			var startDate = new Date();
			const duplicateArray = blocks.slice() // copying blocks array
			const orderOfTraversal = []

			let i, j

			for (i = 0; i < duplicateArray.length; i++) {
				for (j = 0; j < duplicateArray.length - i - 1; j++) {

					orderOfTraversal.push([j, j + 1, null, null])                  // Compare
					if (duplicateArray[j] > duplicateArray[j + 1]) {
						swap(duplicateArray, j, j + 1)
						orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
					}
				}
				orderOfTraversal.push([null, null, null, j]) // j-th element is in correct position ( Sorted )
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal
		}

		let orderOfTraversal = []
		let duplicateArray;
		const fromBook_7_4_5 = (blocks) => {

			var startDate = new Date();
			duplicateArray = blocks.slice() // Copying blocks array
			hybrid_quick_sort(duplicateArray, 0, duplicateArray.length - 1)
			for (let i = 0; i < duplicateArray.length; i++) {
				orderOfTraversal.push([null, null, null, i])
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal
		}



		const partition = (duplicateArray, l, r) => {
			const pivot = l
			let j = l

			for (let i = l + 1; i <= r; i++) {
				orderOfTraversal.push([i, pivot, null, null])
				if (duplicateArray[i] < duplicateArray[pivot]) {
					j += 1
					orderOfTraversal.push([i, j, duplicateArray.slice(), null])
					swap(duplicateArray, i, j)
					orderOfTraversal.push([i, j, duplicateArray.slice(), null])
				}
			}
			orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
			swap(duplicateArray, pivot, j)
			orderOfTraversal.push([pivot, j, duplicateArray.slice(), null])
			orderOfTraversal.push([null, null, null, j])
			return j
		}



		const hybrid_quick_sort = (duplicateArray, l, r) => {
			console.log("In hybrid quick sort value of l and r is " + l + " " + r)
			while (l < r) {
				if (r - l + 1 < 10) {
					insertionSort_(duplicateArray, l, r);
					break
				}
				else {
					let m = partition(duplicateArray, l, r)
					if (m - l < r - m) {
						hybrid_quick_sort(duplicateArray, l, m - 1)
						l = m + 1
					}
					else {
						hybrid_quick_sort(duplicateArray, m + 1, r)
						r = m - 1
					}
				}

			}
			return
		}

		const insertionSort_ = (blocks_, l, r) => {
			console.log("In insertion sort value of l and r is " + l + " " + r)
			let i, j

			for (i = l + 1; i < r + 1; i++) {
				j = i - 1
				while (j >= 0 && duplicateArray[j] > duplicateArray[j + 1]) {
					swap(duplicateArray, j, j + 1)
					orderOfTraversal.push([j, j + 1, null, null])              // Compare
					orderOfTraversal.push([j, j + 1, duplicateArray.slice(), null]) // Swap
					j -= 1

				}
			}
			for (i = l; i < r + 1; i++) {
				orderOfTraversal.push([null, null, null, i])
			}
		}
		const fromBook_8_2_4 = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice() // copying blocks array
			let min = Math.min(...duplicateArray)
			let max = Math.max(...duplicateArray)

			let i = min,
				j = 0,
				len = duplicateArray.length,
				count = [];
			for (i; i <= max; i++) {
				count[i] = 0;
			}
			for (i = 0; i < len; i++) {
				count[duplicateArray[i]] += 1;
			}
			console.log(min)
			for (i = min; i <= max; i++) {
				while (count[i] > 0) {
					duplicateArray[j] = i;
					orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
					console.log(duplicateArray[i])
					count[i]--;
					orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
					j++;
				}
			}
			console.log(duplicateArray)
			let a = prompt("Enter 'a' i.e. the lower limit of the range")
			let b = prompt("Enter 'b' i.e. the upper limit of the range")
			let rangeCount = 0
			for (let i = 0; i < duplicateArray.length; i++) {
				if (duplicateArray[i] >= a && duplicateArray[i] <= b)
					rangeCount++
			}
			alert("There are " + rangeCount + " number that lie within the range of " + a + " and " + b)
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal;
		}

		function getDigit(num, place) {
			return Math.floor(Math.abs(num) / Math.pow(10, place)) % 10
		}

		function digitCount(num) {
			if (num === 0) return 1
			return Math.floor(Math.log10(Math.abs(num))) + 1
		}

		function mostDigits(nums) {
			let maxDigits = 0
			for (let i = 0; i < nums.length; i++) {
				maxDigits = Math.max(maxDigits, digitCount(nums[i]))
			}
			return maxDigits
		}

		const radixSort = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice()
			let holder = []
			let maxDigitCount = mostDigits(duplicateArray)
			for (let k = 0; k < maxDigitCount; k++) {
				holder = []

				let digitBuckets = Array.from({ length: 10 }, () => []) // [[], [], [],...]
				for (let i = 0; i < duplicateArray.length; i++) {
					let digit = getDigit(duplicateArray[i], k)
					digitBuckets[digit].push(duplicateArray[i])
				}
				for (let i = 0; i < digitBuckets.length; i++) {
					for (let j = 0; j < digitBuckets[i].length; j++) {
						if (digitBuckets[i][j] != []) {
							holder.push(digitBuckets[i][j])
						}

					}

				}
				console.log(holder)
				orderOfTraversal.push([null, null, holder.slice(), null]) // Swap
				console.log(duplicateArray)
				// New orderOfTraversal after each loop
				duplicateArray = [].concat(...digitBuckets)
			}
			for (let i = 0; i < holder.length; i++) {
				orderOfTraversal.push([null, null, null, i]) // j-th element is in correct position ( Sorted )
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			// return duplicateArray
			return orderOfTraversal
		}

		const countSort = (blocks) => {
			var startDate = new Date();
			let duplicateArray = blocks.slice() // copying blocks array
			let min = Math.min(...duplicateArray)
			let max = Math.max(...duplicateArray)

			let i = min,
				j = 0,
				len = duplicateArray.length,
				count = [];
			for (i; i <= max; i++) {
				count[i] = 0;
			}
			for (i = 0; i < len; i++) {
				count[duplicateArray[i]] += 1;
			}
			console.log(min)
			for (i = min; i <= max; i++) {
				while (count[i] > 0) {
					duplicateArray[j] = i;
					orderOfTraversal.push([null, null, duplicateArray.slice(), null]) // Swap
					console.log(duplicateArray[i])
					count[i]--;
					orderOfTraversal.push([null, null, null, j]) // i-th element is in correct position ( Sorted )
					j++;
				}
			}
			var endDate = new Date();
			let str = "The time take to sort the array is " + (endDate.getTime() - startDate.getTime()) + " milliseconds"
			alert(str)
			return orderOfTraversal;
		};

		algo === 'bubbleSort' ? sortAccOrder(bubbleSort(blocks)) :
			algo === 'insertionSort' ? sortAccOrder(insertionSort(blocks)) :
				algo === 'selectionSort' ? sortAccOrder(selectionSort(blocks)) :
					algo === 'mergeSort' ? sortAccOrder(mergeSort(blocks)) :
						algo === 'quickSort' ? sortAccOrder(quickSort(blocks)) :
							algo === 'heapSort' ? sortAccOrder(heapSort(blocks)) :
								algo === 'countSort' ? sortAccOrder(countSort(blocks)) :
									algo === 'radixSort' ? sortAccOrder(radixSort(blocks)) :
										algo === 'fromBook_7_4_5' ? sortAccOrder(fromBook_7_4_5(blocks)) :
											algo === 'fromBook_8_2_4' ? sortAccOrder(fromBook_8_2_4(blocks)) :
												(() => {
													setSorting(false)
													setCompleted(true)
												})()

	}

	return (
		// <div className='listBlocks'>

		//     {blocks.map((block, i) => {
		//         const height = block * 500 / blocks.length;
		//         let bg = '#ff8000'

		//         // i th element is being compared with some other element
		//         if(compare && (i === compare[0] || i === compare[1])){
		//             bg = '#ffff50'
		//         }

		//         if(swap && (i === swap[0] || i === swap[1])){
		//             bg='red'
		//         }
		//         // i th element is in its correct position
		//         if(sorted && sorted.includes(i)){
		//             bg = '#4bc52e'
		//         }

		//         const style = {
		//             'backgroundColor': bg,
		//             'color': color, 
		//             'height': height, 
		//             'width': width
		//         }
		//         return (<div key={i} className='block' style={style}>{block}</div>)
		//     })}
		// </div>
		// 	<div className='legends'>
		// 	<div className='key'>
		// 		<span className='sq compare'></span> Compare
		// 	</div>
		// 	<div className='key'>
		// 		<span className='sq swap'></span> {algo !== 'mergeSort' ? 'Swap' : 'Taking From Auxillary Space'}
		// 	</div>
		// 	<div className='key'>
		// 		<span className='sq sorted'></span> Sorted
		// 	</div>
		// </div>
		// <nav>
		//         <div className='nav-brand'>Algo Project: Visualizing algorithms</div>

		//         <div className='toolbox'>
		//             <div>
		//                 <div className='group speed'>
		//                     <label>Speed</label>
		//                     <input type='range' onChange={handleSpeed} min='1' max='10' value={Math.ceil(1200 / speed)} disabled={sorting}></input>
		//                 </div>

		//                 <div className='group length'>
		//                     <label>Length of array</label>
		//                     <input type='range' onChange={handleLength} min='5' max={100} step='1' disabled={sorting} value={len}></input>
		//                 </div>

		//                 <select onChange={handleAlgo} disabled={sorting} value={algo}>
		//                     <option value='bubbleSort'>Bubble Sort</option>
		//                     <option value='insertionSort'>Insertion Sort</option>
		//                     <option value='selectionSort'>Selection Sort</option>
		//                     <option value='mergeSort'>Merge Sort</option>
		//                     <option value='quickSort'>Quick Sort</option>
		//                     <option value='heapSort'>Heap Sort</option>
		//                     <option value='countSort'>Count Sort</option>
		//                     <option value='radixSort'>Radix Sort</option>
		//                     <option value='fromBook_7_4_5'>7.4.5 from book</option>
		//                     <option value='fromBook_8_2_4'>8.2.4 from book</option>
		//                 </select>
		//             </div>

		//             <div>
		//                 <button onClick={generateRandomArray} disabled={sorting}>Randomize</button>
		//                 <button onClick={handleSort} disabled={sorting || completed}>Sort</button>
		//             </div>
		//         </div>
		//     </nav>
		<div className="App">
			<Navbar
				generateRandomArray={() => generateRandomArray(len)}
				handleLength={handleLength}
				handleSpeed={handleSpeed}
				handleAlgo={handleAlgo}
				handleSort={handleSort}
				sorting={sorting}
				completed={completed}
				len={len}
				speed={speed}
				algo={algo}
			/>

			<ListBlocks
				blocks={blocks}
				compare={sorting && compare}
				swap={sorting && swap}
				sorted={sortedIndex}
			/>
			<Legends algo={algo} />

		</div>
	);
}

export default App
