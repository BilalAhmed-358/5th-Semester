# Sorting Visualizer

This application is created using React for visualizing classic sorting algorithms such as merge-sort, quick-sort, insertion-sort, selection-sort, etc.


![screenshot of project](/public/sv.png)

## Setting Up & Running the application

```
  $ git clone https://github.com/BilalAhmed-358/AnanlysisOfAlgorithmsCourseProject.git
  $ cd AnanlysisOfAlgorithmsProject
  $ npm install
  $ npm start
```