#define SIZE 16
#define MINIGRIDSIZE 4

int **readInput(char *);
int isValid(int **, int **);
int **solveSudoku(int **);
