module org.eclipse.papyrus.javagen.Delivery_management_collaboration {
}