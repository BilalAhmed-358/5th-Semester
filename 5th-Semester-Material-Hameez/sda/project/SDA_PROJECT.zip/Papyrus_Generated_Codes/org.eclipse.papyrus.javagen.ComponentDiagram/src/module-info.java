module org.eclipse.papyrus.javagen.ComponentDiagram {
}