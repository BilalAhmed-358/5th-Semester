module org.eclipse.papyrus.javagen.BillingManagement {
}