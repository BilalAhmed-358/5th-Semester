module org.eclipse.papyrus.javagen.project_collaborationDiagram {
}