module DeliveryManagementSequence {
}