module org.eclipse.papyrus.javagen.DeliveryManagement {
}