module org.eclipse.papyrus.javagen.project_usecase {
}