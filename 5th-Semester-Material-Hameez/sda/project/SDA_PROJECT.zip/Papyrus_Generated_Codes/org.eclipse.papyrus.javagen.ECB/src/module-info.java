module org.eclipse.papyrus.javagen.ECB {
}